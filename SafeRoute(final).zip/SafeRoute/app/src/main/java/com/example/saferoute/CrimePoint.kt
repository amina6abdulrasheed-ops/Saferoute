package com.example.saferoute

class CrimePoint(
    var lat: Double,
    var lon: Double,
    var risk: Double
)
